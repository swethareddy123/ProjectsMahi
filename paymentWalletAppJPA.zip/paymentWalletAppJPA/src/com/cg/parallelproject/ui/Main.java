package com.cg.parallelproject.ui;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.parallelproject.dto.Customer;
import com.cg.parallelproject.dto.Transaction;
import com.cg.parallelproject.exception.InsufficientBalanceException;
import com.cg.parallelproject.exception.InvalidInputException;
import com.cg.parallelproject.service.WalletService;
import com.cg.parallelproject.service.WalletServiceImpl;

public class Main {
	private static Scanner sc;

	public static void main(String args[])
	{
	Customer c=new Customer();
	WalletService service=new WalletServiceImpl();
	sc = new Scanner(System.in);
	int ch;
	do
	{
		System.out.println("****************************************");
		System.out.println("--------------WalletApp---------------");
		System.out.println("****************************************");
		
		System.out.println("1.Create Account");
		System.out.println("2.Deposit Amount");
	    System.out.println("3.Withdraw");
		System.out.println("4.Show Balance");
		System.out.println("5.FundTransfer");
		System.out.println("6.PrintTransaction");
		System.out.println("7.Exit");
		System.out.println("Enter ur choice");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			String name;
			String mob;
			double bal;
			do
			{
				try
				{
					System.out.println("Enter name");
					name=sc.next();
					if(service.validateName(name))
					{
						break;
				
					}
				}
				catch(InvalidInputException i)
				{
					System.out.println(i.getMessage());
				}
			}while(true);
			
			do
			{
				try
				{
					System.out.println("Enter mobile number");
					mob=sc.next();
					if(service.validateNumber(mob)&&!service.isNewMobile(mob))
					{
						break;
				
					}
				}
				catch(InvalidInputException i)
				{
					System.out.println(i.getMessage());
				}
			}while(true);
			
			do
			{
				try
				{
					System.out.println("Enter intial balance");
					bal=sc.nextDouble();
					if(service.validateBalance(bal))
					{
						c=service.createAccount(name,mob,bal);
						break;
				
					}
				}
				catch(InvalidInputException i)
				{
					System.out.println(i.getMessage());
				}
				catch(InsufficientBalanceException i)
				{
					System.out.println(i.getMessage());
				}
			}while(true);
			
			
			System.out.println(c.getName()+" "+c.getMobileNo()+" "+c.getBalance());
			break;
			
		case 2:
//			String mobi;
//			Double amt;
//			do
//			{
//			try
//			{
//				System.out.println("Enter the mobile no. that you registered for the account");
//				mobi=sc.next();
//				System.out.println("Enter the amount you want to deposit");
//				amt=sc.nextDouble();
//				if(service.validateNumber(mobi))
//				{
//					c=service.depositAmount(mobi, amt);
//					break;
//				}
//			}
//			catch(InvalidInputException e)
//			{
//				System.out.println(e.getMessage());
//			}
//			catch(InsufficientBalanceException e)
//			{
//				System.out.println(e.getMessage());
//			}
//			}while(true);
//			
//			System.out.println(c.getName()+" "+c.getMobileNo()+" "+c.getBalance());
//			break;
			String mobi;
			double amt;
		
			do{
				try
				{
				System.out.println("Enter the mobile no. that you registered for the account");
				mobi=sc.next();
				if(service.validateNumber(mobi)&&!service.isAvailableMobile(mobi))
					break;
				}
				catch(InvalidInputException e)
				{
					System.out.println(e.getMessage());
				}
			}while(true);
			do{
				try
				{
					System.out.println("Enter the amount you want to deposit");
					amt=sc.nextDouble();
					c=service.depositAmount(mobi, amt);
					//System.out.println(c.getName()+" "+c.getMobileNo()+" "+c.getWallet().getBalance());
					System.out.println(c.getName()+" "+c.getMobileNo()+" "+c.getBalance());
					break;
				}
				catch(InsufficientBalanceException e)
				{
					System.out.println(e.getMessage());
				}
				
			}while(true);
				
					
					
			break;
		case 3:
//			do
//			{
//				try
//				{
//					String mobil;
//					
//					System.out.println("Enter the mobile no. that you registered for the account");
//					mobil=sc.next();
//					System.out.println("Enter the amount you want to withdraw");
//					double at=sc.nextDouble();
//					if(service.validateNumber(mobil))
//					{
//						c=service.withdrawAmount(mobil, at);
//						break;
//					}
//				
//				}
//				catch(InvalidInputException e)
//				{
//					System.out.println(e.getMessage());
//				}
//				catch(InsufficientBalanceException e)
//				{
//					System.out.println(e.getMessage());
//				}
//			}while(true);
			String mobil;
			double amt1;
			
			do{
				try
				{
				System.out.println("Enter the mobile no. that you registered for the account");
				mobil=sc.next();
				if(service.validateNumber(mobil)&&!service.isAvailableMobile(mobil))
					break;
				}
				catch(InvalidInputException e)
				{
					System.out.println(e.getMessage());
				}
			}while(true);
			do{
				try
				{
					System.out.println("Enter the amount you want to withdraw");
					amt1=sc.nextDouble();
					c=service.withdrawAmount(mobil, amt1);
					//System.out.println(c.getName()+" "+c.getMobileNo()+" "+c.getWallet().getBalance());
					System.out.println(c.getName()+" "+c.getMobileNo()+" "+c.getBalance());
					break;
				}
				catch(InsufficientBalanceException e)
				{
					System.out.println(e.getMessage());
				}
				
			}while(true);
			break;
			
			

		case 4:
			do
			{
			System.out.println("Enter registered mobile no.");
			String mobile=sc.next();
			try
			{
				if(service.validateNumber(mobile))
				{
					c=service.showBalance(mobile);
					break;
				}
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			
			}while(true);
			System.out.println("Hello "+c.getName()+" Your Available Balance: "+c.getBalance());
			break;
		case 5:
//			do
//			{
//				System.out.println("Enter ur registered mobile no.");
//				String mob1=sc.next();
//				System.out.println("Enter mobile no. registered on app of the receiver");
//				String mob2=sc.next();
//				System.out.println("Enter amount you want to transfer");
//				double amount=sc.nextDouble();
//				try
//				{
//					if(service.validateNumber(mob1)&&service.validateNumber(mob2))
//					{
//						c=service.fundTransfer(mob1, mob2, amount);
//						break;
//					}
//				}
//				catch(InvalidInputException e)
//				{
//					System.out.println(e.getMessage());
//				}
//				catch(InsufficientBalanceException e)
//				{
//					System.out.println(e.getMessage());
//				}
//			}while(true);
//			
//			if(c!=null)
//			{
//				System.out.println("Transfered amount successfully");
//				System.out.println("Available balance in account: "+c.getName()+" with mobile no. "+c.getMobileNo()+" is "+c.getBalance());
//			}	
//			else
//				System.out.println("Transfer failed");
//			break;
			String mob1;
			String mob2;
				do
				{
					try{
				System.out.println("Enter ur registered mobile no.");
				mob1=sc.next();
				if(service.validateNumber(mob1)&&!service.isAvailableMobile(mob1))
					break;
					}
					catch(InvalidInputException e)
					{
						System.out.println("Sender "+e.getMessage());
					}
				}while(true);
				
				do
				{
					try{
						System.out.println("Enter mobile no. registered on app of the receiver");
						mob2=sc.next();
				if(service.validateNumber(mob2)&&!service.isAvailableMobile(mob2))
					break;
					}
					catch(InvalidInputException e)
					{
						System.out.println("Receiver "+e.getMessage());
					}
				}while(true);
				do
				{
				System.out.println("Enter amount you want to transfer");
				double amount=sc.nextDouble();
				try{
						c=service.fundTransfer(mob1, mob2, amount);
						break;
				}
				catch(InvalidInputException e)
				{
					System.out.println(e.getMessage());
				}
				catch(InsufficientBalanceException e)
				{
					System.out.println(e.getMessage());
				}
			}while(true);
			
			if(c!=null)
			{
				System.out.println("Transfered amount successfully");
				//System.out.println("Available balance in account: "+c.getName()+" with mobile no. "+c.getMobileNo()+" is "+c.getWallet().getBalance());
				System.out.println("Available balance in account: "+c.getName()+" with mobile no. "+c.getMobileNo()+" is "+c.getBalance());
			
			}	
			else
				System.out.println("Transfer failed");
			break;
		case 6:
			String mobile;
			do{
				
			System.out.println("Enter mobile to show all transaction");
			mobile=sc.next();
			try
			{

			if(service.validateNumber(mobile))
			{
				List<Transaction> allTran=service.getAllTransactions(mobile);
				List<Transaction> b=new ArrayList<Transaction>();
				if(allTran.equals(b))
				{
					System.out.println("No transactions done till now");
				}
				int i=0;
				for(Transaction t:allTran)
				{
					i++;
					System.out.println("S.NO: "+i+" "+t.toString());
				}
			}
				break;
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			}while(true);
			break;
		
		case 7:
			System.out.println("Thanks for using our application");
			break;
		}
		
		
	}while(ch!=7);
	
	}
}
