package com.cg.parallelproject.service;
import java.util.List;

import com.cg.parallelproject.dto.Customer;
import com.cg.parallelproject.dto.Transaction;


public interface WalletService {
public Customer createAccount(String name ,String mobileno, double amount);
public Customer showBalance (String mobileno);
public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, double amount);
public Customer depositAmount (String mobileNo,double amount );
public Customer withdrawAmount(String mobileNo, double amount);
public boolean validateName(String name);
public boolean validateNumber(String number);
public boolean validateBalance(double number);
public boolean findNumber(String mobile);
public boolean isNewMobile(String mob);
public boolean isAvailableMobile(String mob);
public List<Transaction> getAllTransactions(String mobile);
}
